
import { Member, ClassRecap, UserRole, SportType, Class, Booking, Club, ClubAlert, TrainingEvent } from '../types';
import { supabase } from './supabaseClient';

export const dataService = {
  async signUp(email: string, password: string, username: string) {
    const { data, error } = await (supabase.auth as any).signUp({
      email,
      password,
      options: { data: { username } }
    });
    if (error) throw error;
    return data;
  },

  async verifyEmail(email: string, token: string) {
    const { data, error } = await supabase.auth.verifyOtp({
      email,
      token,
      type: 'signup'
    });
    if (error) throw error;
    return data;
  },

  async signIn(email: string, password: string) {
    const auth = supabase.auth as any;
    const signInMethod = auth.signInWithPassword || auth.signIn;
    const { data, error } = await signInMethod.call(auth, {
      email,
      password,
    });
    if (error) throw error;
    return data;
  },

  async signOut() {
    const { error } = await supabase.auth.signOut();
    if (error) throw error;
  },

  async getProfile(userId: string) {
    const { data, error } = await supabase
      .from('profiles')
      .select('*')
      .eq('id', userId)
      .single();
    
    if (error && error.code !== 'PGRST116') throw error;
    return data;
  },

  async updateProfile(userId: string, updates: any) {
    const { error } = await supabase
      .from('profiles')
      .update(updates)
      .eq('id', userId);
    if (error) throw error;
  },

  async getUserMemberships(userId: string) {
    const { data, error } = await supabase
      .from('memberships')
      .select('*, clubs(*)')
      .eq('user_id', userId);
    
    if (error) throw error;
    return data;
  },

  async createClub(ownerId: string, name: string, customId: string, sport: SportType) {
    const { data: club, error: clubError } = await supabase
      .from('clubs')
      .insert([{ name, custom_id: customId, sport, owner_id: ownerId }])
      .select()
      .single();

    if (clubError) throw clubError;

    await supabase
      .from('memberships')
      .insert([{ user_id: ownerId, club_id: club.id, role: 'OWNER' }]);

    return club;
  },

  async updateClub(clubId: string, updates: any) {
    const { error } = await supabase
      .from('clubs')
      .update(updates)
      .eq('id', clubId);
    if (error) throw error;
  },

  async updateMembershipRole(clubId: string, userId: string, role: string) {
    const { error } = await supabase
      .from('memberships')
      .update({ role })
      .eq('club_id', clubId)
      .eq('user_id', userId);
    if (error) throw error;
  },

  async deleteClub(clubId: string) {
    await supabase.from('bookings').delete().eq('club_id', clubId);
    await supabase.from('classes').delete().eq('club_id', clubId);
    await supabase.from('memberships').delete().eq('club_id', clubId);
    const { error } = await supabase.from('clubs').delete().eq('id', clubId);
    if (error) throw error;
  },

  async joinClub(userId: string, customClubId: string) {
    const { data: club, error: clubError } = await supabase
      .from('clubs')
      .select('id')
      .eq('custom_id', customClubId)
      .single();

    if (clubError) throw new Error("Club not found.");

    await supabase
      .from('memberships')
      .insert([{ user_id: userId, club_id: club.id, role: 'MEMBER' }]);

    return club;
  },

  async getMembers(clubId: string): Promise<Member[]> {
    const { data, error } = await supabase
      .from('memberships')
      .select('user_id, role, profiles(*)')
      .eq('club_id', clubId);

    if (error || !data) return [];

    return data.map((m: any) => {
      const p = Array.isArray(m.profiles) ? m.profiles[0] : m.profiles;
      return {
        id: m.user_id,
        name: p?.username || 'Grappler',
        rank: p?.rank || 'White',
        stripes: p?.stripes || 0,
        totalSessions: p?.total_sessions || 0,
        joinDate: p?.created_at,
        is_premium_member: p?.is_premium_member || false,
        avatar_url: p?.avatar_url,
        role: m.role,
        lastAttendance: p?.last_attendance
      };
    });
  },

  async removeMember(clubId: string, userId: string) {
    const { error } = await supabase
      .from('memberships')
      .delete()
      .eq('club_id', clubId)
      .eq('user_id', userId);
    if (error) throw error;
  },

  async getClasses(clubId: string): Promise<Class[]> {
    const { data, error } = await supabase
      .from('classes')
      .select('*')
      .eq('club_id', clubId)
      .order('day', { ascending: true })
      .order('time', { ascending: true });

    if (error) return [];
    return data;
  },

  async createClass(clubId: string, classData: Omit<Class, 'id' | 'club_id'>): Promise<void> {
    const { error } = await supabase
      .from('classes')
      .insert([{ club_id: clubId, ...classData }]);
    if (error) throw error;
  },

  async updateClass(classId: string, updates: Partial<Class>) {
    const { error } = await supabase
      .from('classes')
      .update(updates)
      .eq('id', classId);
    if (error) throw error;
  },

  async getBookingCount(classId: string, date: string): Promise<number> {
    const { count, error } = await supabase
      .from('bookings')
      .select('*', { count: 'exact', head: true })
      .eq('class_id', classId)
      .eq('date', date);
    
    if (error) return 0;
    return count || 0;
  },

  async getClassAttendees(classId: string, date: string): Promise<Member[]> {
    const { data, error } = await supabase
      .from('bookings')
      .select('user_id, profiles(*)')
      .eq('class_id', classId)
      .eq('date', date);

    if (error || !data) return [];
    
    return data.map((b: any) => {
      const p = Array.isArray(b.profiles) ? b.profiles[0] : b.profiles;
      return {
        id: b.user_id,
        name: p?.username || 'Grappler',
        rank: p?.rank || 'White',
        stripes: p?.stripes || 0,
        totalSessions: p?.total_sessions || 0,
        joinDate: p?.created_at,
        is_premium_member: p?.is_premium_member || false,
        avatar_url: p?.avatar_url
      };
    });
  },

  async bookClass(userId: string, classId: string, date: string): Promise<void> {
    const { error } = await supabase
      .from('bookings')
      .insert([{ user_id: userId, class_id: classId, date }]);
    if (error) throw error;
  },

  async getNextBooking(userId: string): Promise<(Booking & { classes: Class }) | null> {
    const { data, error } = await supabase
      .from('bookings')
      .select('*, classes(*)')
      .eq('user_id', userId)
      .order('date', { ascending: false })
      .limit(1)
      .maybeSingle();
    
    if (error) return null;
    return data;
  },

  async postAlert(clubId: string, message: string, type: string) {
    const { error } = await supabase
      .from('club_alerts')
      .insert([{ club_id: clubId, message, type }]);
    if (error) throw error;
  },

  async getAlerts(clubId: string): Promise<ClubAlert[]> {
    const { data, error } = await supabase
      .from('club_alerts')
      .select('*')
      .eq('club_id', clubId)
      .order('created_at', { ascending: false })
      .limit(1);
    return data || [];
  },

  async createEvent(clubId: string, eventData: Omit<TrainingEvent, 'id' | 'club_id'>) {
    const { error } = await supabase
      .from('training_events')
      .insert([{ club_id: clubId, ...eventData }]);
    if (error) throw error;
  },

  async getEvents(clubId: string): Promise<TrainingEvent[]> {
    const { data, error } = await supabase
      .from('training_events')
      .select('*')
      .eq('club_id', clubId)
      .order('event_date', { ascending: true });
    return data || [];
  },

  async saveRecap(clubId: string, recapData: Omit<ClassRecap, 'id' | 'club_id' | 'date'>) {
    const { error } = await supabase
      .from('class_recap')
      .insert([{
        club_id: clubId,
        ...recapData,
        date: new Date().toISOString().split('T')[0]
      }]);
    if (error) throw error;
  },

  async getRecaps(clubId: string): Promise<ClassRecap[]> {
    const { data, error } = await supabase
      .from('class_recap')
      .select('*')
      .eq('club_id', clubId)
      .order('date', { ascending: false });
    if (error) return [];
    return data;
  }
};
